This zip contains hyperlynx.ulp for Eagle version 6.3 and higher. 

hyperlynx.ulp is a script to export Eagle boards to Hyperlynx. 
The boards are then simulated using Hyperlynx (commercial) or openEMS (open source). Striplines and microstrips can be simulated this way.

Difference between this script and the standard Eagle hyperlynx.ulp:
- uses layer names instead of layer numbers
- adds export of polygons
- correctly exports copper thickness.

Hyperlynx is a simulation package from Mentor Graphics, http://www.mentor.com
openEMS is an open source electromagnetic field solver, http://www.openems.de

koen

14.11.12


