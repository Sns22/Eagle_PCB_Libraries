tle2426.5_1	(5V)Rail Splitter Virtual Ground Generator	1	TLE2426 "Macromodel" Subcircuit
tle2426.5_2	(5V)Rail Splitter Virtual Ground Generator	2	TLE2426 "Macromodel" Subcircuit
